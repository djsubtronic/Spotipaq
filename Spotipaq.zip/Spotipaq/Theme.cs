// Theme.cs - colours, fonts and shared drawing helpers (Spotify 1.0-era dark theme, green accent).
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Drawing.Imaging;
using System.IO;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Spotipaq
{
    public static class Theme
    {
        public static readonly Color Accent = Color.FromArgb(29, 185, 84);        // #1DB954
        public static readonly Color AccentHover = Color.FromArgb(30, 215, 96);   // #1ED760
        public static readonly Color Main = Color.FromArgb(24, 24, 24);           // content area
        public static readonly Color Sidebar = Color.FromArgb(18, 18, 18);
        public static readonly Color Bar = Color.FromArgb(40, 40, 40);            // top + bottom bars
        public static readonly Color RowHover = Color.FromArgb(51, 51, 51);
        public static readonly Color RowSelected = Color.FromArgb(64, 64, 64);
        public static readonly Color Line = Color.FromArgb(40, 40, 40);
        public static readonly Color Text = Color.White;
        public static readonly Color SubText = Color.FromArgb(160, 160, 160);
        public static readonly Color DimText = Color.FromArgb(110, 110, 110);
        public static readonly Color Placeholder = Color.FromArgb(62, 62, 62);

        // Text: Segoe UI Variable's "Text" optical size; big titles: its "Display" size. GDI+ (.NET 2.0) can't pick
        // variable-font axes, but the named instances appear as separate families. Fallbacks only matter on
        // machines without it.
        public static readonly string FontFamilyName = PickFamily("Segoe UI Variable Text", "Segoe UI Variable", "Segoe UI", "Tahoma");
        public static readonly string DisplayFamilyName = PickFamily("Segoe UI Variable Display", "Segoe UI Variable", "Segoe UI", "Tahoma");
        public static readonly Font Small = Make(8.25f, FontStyle.Regular);
        public static readonly Font SmallBold = Make(8.25f, FontStyle.Bold);
        public static readonly Font Normal = Make(9f, FontStyle.Regular);
        public static readonly Font NormalBold = Make(9f, FontStyle.Bold);
        public static readonly Font Heading = Make(12f, FontStyle.Bold);
        public static readonly Font Huge = new Font(DisplayFamilyName, 20f, FontStyle.Bold);
        public static readonly Font Label = Make(7.5f, FontStyle.Bold);           // "ALBUM", section headers

        static string PickFamily(params string[] wanted)
        {
            Dictionary<string, bool> have = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
            using (InstalledFontCollection fonts = new InstalledFontCollection())
                foreach (FontFamily f in fonts.Families) have[f.Name] = true;
            foreach (string name in wanted) if (have.ContainsKey(name)) return name;
            return "Tahoma";
        }
        static Font Make(float size, FontStyle style) { return new Font(FontFamilyName, size, style); }

        public const TextFormatFlags LeftEllipsis = TextFormatFlags.Left | TextFormatFlags.VerticalCenter |
            TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine;

        public static void Text1(Graphics g, string s, Font f, Rectangle r, Color c)
        {
            Draw(g, s, f, r, c, LeftEllipsis);
        }

        // ---- text with symbol / emoji fallback ----
        // Segoe UI Variable has no emoji or symbols. Plain strings go through TextRenderer (fast, crisp);
        // strings containing such characters are split into runs and the symbol runs are drawn with GDI+,
        // which does its own glyph fallback. Optionally put a font name in %APPDATA%\Spotipaq\symbolfont.txt.
        static readonly string SymbolFamilyName = PickSymbolFamily();
        static readonly Dictionary<Font, Font> _symFonts = new Dictionary<Font, Font>();

        static string PickSymbolFamily()
        {
            string wanted = null;
            try
            {
                string f = System.IO.Path.Combine(Spotipaq.Engine.Log.Folder, "symbolfont.txt");
                if (System.IO.File.Exists(f)) wanted = System.IO.File.ReadAllText(f).Trim();
            }
            catch { }
            string pick;
            if (!String.IsNullOrEmpty(wanted)) pick = PickFamily(wanted, "Segoe UI Emoji", "Segoe UI Symbol", "Arial Unicode MS", "Lucida Sans Unicode");
            else pick = PickFamily("Segoe UI Emoji", "Segoe UI Symbol", "Arial Unicode MS", "Lucida Sans Unicode");
            try { Spotipaq.Engine.Log.Write("Symbol/emoji font: " + pick); } catch { }
            return pick;
        }

        static bool IsSpecial(char c)
        {
            return (c >= 0xD800 && c <= 0xDFFF) || (c >= 0x2190 && c <= 0x2BFF) || (c >= 0x2E80 && c < 0xD800) ||
                   (c >= 0xFE00 && c <= 0xFE0F) || c == 0x200D || (c >= 0x2600 && c <= 0x27BF);
        }

        static bool IsInvisible(char c) { return (c >= 0xFE00 && c <= 0xFE0F) || c == 0x200D; }

        static bool HasSpecial(string s)
        {
            for (int i = 0; i < s.Length; i++) if (IsSpecial(s[i])) return true;
            return false;
        }

        static Font SymbolFont(Font f)
        {
            Font r;
            lock (_symFonts)
            {
                if (!_symFonts.TryGetValue(f, out r))
                {
                    try { r = new Font(SymbolFamilyName, f.Size, f.Style); } catch { r = f; }
                    _symFonts[f] = r;
                }
            }
            return r;
        }

        sealed class Run { public string Text; public bool Special; public int Width; }

        static int RunWidth(Graphics g, string s, Font f, bool special)
        {
            if (s.Length == 0) return 0;
            if (!special) return TextRenderer.MeasureText(g, s, f, new Size(int.MaxValue, int.MaxValue), TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine).Width;
            using (StringFormat sf = new StringFormat(StringFormat.GenericTypographic))
            {
                sf.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;
                return (int)Math.Ceiling(g.MeasureString(s, SymbolFont(f), PointF.Empty, sf).Width);
            }
        }

        static List<Run> SplitRuns(Graphics g, string text, Font f)
        {
            List<Run> runs = new List<Run>();
            StringBuilder sb = new StringBuilder();
            bool special = false;
            for (int i = 0; i < text.Length; i++)
            {
                char ch = text[i];
                if (IsInvisible(ch)) continue;
                bool sp = IsSpecial(ch);
                if (sp != special && sb.Length > 0) { runs.Add(new Run { Text = sb.ToString(), Special = special }); sb.Length = 0; }
                special = sp;
                sb.Append(ch);
            }
            if (sb.Length > 0) runs.Add(new Run { Text = sb.ToString(), Special = special });
            foreach (Run r in runs) r.Width = RunWidth(g, r.Text, f, r.Special);
            return runs;
        }

        public static Size Measure(string text, Font f)
        {
            if (String.IsNullOrEmpty(text) || !HasSpecial(text)) return TextRenderer.MeasureText(text ?? "", f);
            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
            {
                int w = 4;
                foreach (Run r in SplitRuns(g, text, f)) w += r.Width;
                return new Size(w, TextRenderer.MeasureText("Ag", f).Height);
            }
        }

        public static void Draw(Graphics g, string text, Font f, Rectangle r, Color c, TextFormatFlags flags)
        {
            if (String.IsNullOrEmpty(text) || !HasSpecial(text)) { TextRenderer.DrawText(g, text ?? "", f, r, c, flags); return; }

            List<Run> runs = SplitRuns(g, text, f);
            int total = 0;
            foreach (Run run in runs) total += run.Width;
            int pad = 2;
            int avail = r.Width - pad * 2;
            if (total > avail && (flags & TextFormatFlags.EndEllipsis) != 0)
            {
                int ell = RunWidth(g, "...", f, false);
                int budget = avail - ell, used = 0;
                List<Run> kept = new List<Run>();
                foreach (Run run in runs)
                {
                    if (used + run.Width <= budget) { kept.Add(run); used += run.Width; continue; }
                    string s = run.Text;
                    while (s.Length > 0 && used + RunWidth(g, s, f, run.Special) > budget)
                    {
                        s = s.Substring(0, s.Length - 1);
                        if (s.Length > 0 && Char.IsHighSurrogate(s[s.Length - 1])) s = s.Substring(0, s.Length - 1);
                    }
                    if (s.Length > 0) { Run part = new Run(); part.Text = s; part.Special = run.Special; part.Width = RunWidth(g, s, f, run.Special); kept.Add(part); used += part.Width; }
                    break;
                }
                Run dots = new Run(); dots.Text = "..."; dots.Special = false; dots.Width = ell; kept.Add(dots);
                runs = kept; total = used + ell;
            }
            int x = r.Left + pad;
            if ((flags & TextFormatFlags.Right) != 0) x = r.Right - pad - total;
            else if ((flags & TextFormatFlags.HorizontalCenter) != 0) x = r.Left + (r.Width - total) / 2;
            int lineH = TextRenderer.MeasureText("Ag", f).Height;
            int y = (flags & TextFormatFlags.VerticalCenter) != 0 ? r.Top + (r.Height - lineH) / 2 : r.Top;

            Region oldClip = g.Clip;
            g.SetClip(r, CombineMode.Intersect);
            TextRenderingHint oldHint = g.TextRenderingHint;
            foreach (Run run in runs)
            {
                if (run.Special)
                {
                    g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit;
                    using (SolidBrush b = new SolidBrush(c))
                    using (StringFormat sf = new StringFormat(StringFormat.GenericTypographic))
                    {
                        sf.FormatFlags |= StringFormatFlags.NoWrap;
                        Font sym = SymbolFont(f);
                        float symH = sym.GetHeight(g);
                        g.DrawString(run.Text, sym, b, x, y + (lineH - symH) / 2f, sf);
                    }
                }
                else
                    TextRenderer.DrawText(g, run.Text, f, new Point(x, y), c, TextFormatFlags.NoPadding | TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine);
                x += run.Width;
            }
            g.TextRenderingHint = oldHint;
            g.Clip = oldClip;
        }


        public static string Time(int ms)
        {
            int s = Math.Max(0, ms / 1000);
            return s >= 3600 ? String.Format("{0}:{1:00}:{2:00}", s / 3600, s / 60 % 60, s % 60)
                             : String.Format("{0}:{1:00}", s / 60, s % 60);
        }

        public static GraphicsPath Pill(Rectangle r)
        {
            GraphicsPath p = new GraphicsPath();
            int d = r.Height;
            p.AddArc(r.Left, r.Top, d, d, 90, 180);
            p.AddArc(r.Right - d, r.Top, d, d, 270, 180);
            p.CloseFigure();
            return p;
        }

        /// <summary>Green filled pill (PLAY) or outlined pill (SAVE / FOLLOW) with centred caption.</summary>
        public static void PillButton(Graphics g, Rectangle r, string text, bool filled, bool hot)
        {
            SmoothingMode old = g.SmoothingMode;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            using (GraphicsPath p = Pill(r))
            {
                if (filled)
                    using (SolidBrush b = new SolidBrush(hot ? AccentHover : Accent)) g.FillPath(b, p);
                else
                    using (Pen pen = new Pen(hot ? Color.White : Color.FromArgb(180, 180, 180), 1.5f)) g.DrawPath(pen, p);
            }
            g.SmoothingMode = old;
            Draw(g, text, SmallBold, r, Color.White,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }

        /// <summary>Draws an image scaled to fill r (centre-cropped), or a grey record placeholder.</summary>
        public static void Art(Graphics g, Image img, Rectangle r, bool round)
        {
            if (img == null)
            {
                using (SolidBrush b = new SolidBrush(Placeholder))
                {
                    if (round) { g.SmoothingMode = SmoothingMode.AntiAlias; g.FillEllipse(b, r); g.SmoothingMode = SmoothingMode.None; }
                    else g.FillRectangle(b, r);
                }
                int d = Math.Max(4, r.Width / 5);
                using (SolidBrush hole = new SolidBrush(Color.FromArgb(40, 40, 40)))
                    g.FillEllipse(hole, r.Left + (r.Width - d) / 2, r.Top + (r.Height - d) / 2, d, d);
                return;
            }
            if (!round) { g.DrawImage(img, r); return; }
            using (GraphicsPath clip = new GraphicsPath())
            {
                clip.AddEllipse(r);
                Region old = g.Clip;
                g.SetClip(clip, CombineMode.Intersect);
                g.DrawImage(img, r);
                g.Clip = old;
            }
        }
    }

    /// <summary>
    /// Asynchronous, disk-backed artwork cache. Only scaled 32-bit thumbnails are held
    /// in memory (4 MiB). The compressed disk cache persists across runs (256 MiB).
    /// Image decoding, scaling and file operations all run on one BelowNormal worker.
    /// Get is called on the UI thread; Loaded is raised on that same thread.
    /// </summary>
    public sealed class ImageCache
    {
        public event EventHandler Loaded;
        readonly ISpotifyBackend _backend;
        readonly Control _ui;
        readonly Dictionary<string, Bitmap> _scaled = new Dictionary<string, Bitmap>();
        readonly LinkedList<string> _lru = new LinkedList<string>();
        readonly Dictionary<string, LinkedListNode<string>> _nodes = new Dictionary<string, LinkedListNode<string>>();
        readonly Dictionary<string, bool> _requested = new Dictionary<string, bool>();
        readonly Queue<ArtRequest> _queue = new Queue<ArtRequest>();
        readonly object _lock = new object();
        readonly string _folder;
        const long MaxDiskBytes = 256L * 1024 * 1024;
        const long MaxMemoryBytes = 4L * 1024 * 1024;
        long _memoryBytes;
        int _writesSinceTrim;

        sealed class ArtRequest { public string Url; public int Width; public int Height; public string Key; }

        public ImageCache(ISpotifyBackend backend, Control ui)
        {
            _backend = backend;
            _ui = ui;
            _folder = Path.Combine(Spotipaq.Engine.Log.Folder, "artcache");
            Thread t = new Thread(Worker);
            t.IsBackground = true;
            t.Priority = ThreadPriority.BelowNormal;
            t.Name = "Artwork loader";
            t.Start();
        }

        /// <summary>Never accesses disk, decodes or scales on the UI thread.</summary>
        public Bitmap Get(string url, int w, int h)
        {
            if (String.IsNullOrEmpty(url) || w <= 0 || h <= 0) return null;
            string key = url + "@" + w + "x" + h;
            Bitmap bmp;
            if (_scaled.TryGetValue(key, out bmp))
            {
                LinkedListNode<string> node;
                if (_nodes.TryGetValue(key, out node))
                {
                    _lru.Remove(node);
                    _lru.AddLast(node);
                }
                return bmp;
            }
            lock (_lock)
            {
                if (!_requested.ContainsKey(key))
                {
                    _requested[key] = true;
                    _queue.Enqueue(new ArtRequest { Url = url, Width = w, Height = h, Key = key });
                    Monitor.Pulse(_lock);
                }
            }
            return null;
        }

        static long BitmapBytes(Bitmap bmp) { return (long)bmp.Width * bmp.Height * 4; }

        // UI thread only. Never dispose a bitmap concurrently with its being painted.
        void Publish(ArtRequest req, Bitmap bmp)
        {
            if (_ui.IsDisposed) { bmp.Dispose(); return; }
            lock (_lock) _requested.Remove(req.Key);
            if (_scaled.ContainsKey(req.Key)) { bmp.Dispose(); return; }
            long size = BitmapBytes(bmp);
            if (size > MaxMemoryBytes) { bmp.Dispose(); return; }
            _scaled[req.Key] = bmp;
            _nodes[req.Key] = _lru.AddLast(req.Key);
            _memoryBytes += size;
            while (_memoryBytes > MaxMemoryBytes && _lru.Count > 0)
            {
                string oldest = _lru.First.Value;
                _lru.RemoveFirst();
                _nodes.Remove(oldest);
                Bitmap old = _scaled[oldest];
                _scaled.Remove(oldest);
                _memoryBytes -= BitmapBytes(old);
                old.Dispose();
            }
            if (Loaded != null) Loaded(this, EventArgs.Empty);
        }

        static string FileName(string url)
        {
            byte[] data = Encoding.UTF8.GetBytes(url);
            using (SHA256 sha = SHA256.Create())
            {
                byte[] hash = sha.ComputeHash(data);
                StringBuilder hex = new StringBuilder(68);
                for (int i = 0; i < hash.Length; i++) hex.Append(hash[i].ToString("x2"));
                return hex.ToString() + ".jpg";
            }
        }

        static Bitmap Scale(Bitmap src, int w, int h)
        {
            Bitmap dst = new Bitmap(w, h, PixelFormat.Format32bppPArgb);
            using (Graphics g = Graphics.FromImage(dst))
            {
                g.InterpolationMode = InterpolationMode.HighQualityBilinear;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                float sa = (float)src.Width / src.Height, da = (float)w / h;
                RectangleF from = sa > da ? new RectangleF((src.Width - src.Height * da) / 2, 0, src.Height * da, src.Height)
                                          : new RectangleF(0, (src.Height - src.Width / da) / 2, src.Width, src.Width / da);
                g.DrawImage(src, new Rectangle(0, 0, w, h), from, GraphicsUnit.Pixel);
            }
            return dst;
        }

        void Worker()
        {
            try { Directory.CreateDirectory(_folder); TrimDisk(); }
            catch (Exception ex) { Spotipaq.Engine.Log.Write("Artwork cache init failed: " + ex.Message); }
            while (true)
            {
                ArtRequest req;
                lock (_lock)
                {
                    while (_queue.Count == 0) Monitor.Wait(_lock);
                    req = _queue.Dequeue();
                }
                Bitmap result = null;
                try
                {
                    string path = Path.Combine(_folder, FileName(req.Url));
                    Bitmap original = null;
                    if (File.Exists(path))
                    {
                        try
                        {
                            // Clone so the cached file is never locked while in use.
                            using (Image cached = Image.FromFile(path)) original = new Bitmap(cached);
                            // Touch at most daily to avoid a disk write on every cache hit.
                            if ((DateTime.UtcNow - File.GetLastWriteTimeUtc(path)).TotalDays >= 1)
                                File.SetLastWriteTimeUtc(path, DateTime.UtcNow);
                        }
                        catch
                        {
                            if (original != null) original.Dispose();
                            original = null;
                            try { File.Delete(path); } catch { }
                        }
                    }
                    if (original == null)
                    {
                        original = _backend.LoadImage(req.Url);
                        if (original != null)
                        {
                            try
                            {
                                // Write atomically; an interrupted run cannot poison the cache.
                                string temp = path + ".tmp";
                                original.Save(temp, ImageFormat.Jpeg);
                                if (File.Exists(path)) File.Delete(temp);
                                else File.Move(temp, path);
                                if (++_writesSinceTrim >= 32) { _writesSinceTrim = 0; TrimDisk(); }
                            }
                            catch (Exception ex) { Spotipaq.Engine.Log.Write("Artwork cache write failed: " + ex.Message); }
                        }
                    }
                    if (original != null)
                    {
                        using (original) result = Scale(original, req.Width, req.Height);
                    }
                }
                catch (Exception ex) { Spotipaq.Engine.Log.Write("Artwork load failed: " + ex.Message); }

                if (result == null)
                {
                    lock (_lock) _requested.Remove(req.Key);
                    continue;
                }
                try
                {
                    if (_ui.IsHandleCreated && !_ui.IsDisposed)
                    {
                        Bitmap ready = result;
                        _ui.BeginInvoke(new MethodInvoker(delegate { Publish(req, ready); }));
                        result = null;
                    }
                }
                catch (InvalidOperationException) { }
                if (result != null)
                {
                    result.Dispose();
                    lock (_lock) _requested.Remove(req.Key);
                }
            }
        }

        // Worker thread only; startup and every 32 new cached images, not per frame.
        void TrimDisk()
        {
            FileInfo[] files = new DirectoryInfo(_folder).GetFiles("*.jpg");
            long total = 0;
            foreach (FileInfo f in files) total += f.Length;
            if (total <= MaxDiskBytes) return;
            Array.Sort(files, delegate (FileInfo a, FileInfo b) { return a.LastWriteTimeUtc.CompareTo(b.LastWriteTimeUtc); });
            foreach (FileInfo f in files)
            {
                if (total <= MaxDiskBytes) break;
                try { long n = f.Length; f.Delete(); total -= n; }
                catch { }
            }
        }
    }

    /// <summary>Gives the window its proper small (16px) and large icon straight from the exe, so XP doesn't rescale one size.</summary>
    public static class AppIcon
    {
        [DllImport("shell32.dll", CharSet = CharSet.Auto)] static extern int ExtractIconEx(string file, int index, IntPtr[] large, IntPtr[] small, int count);
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll")] static extern IntPtr CreateIconFromResourceEx(byte[] bits, int size, bool icon, int ver, int cx, int cy, int flags);
        static IntPtr _small, _large;
        static bool _loaded;
        const int SmallBits = 32;      // taskbar icon: 32 = alpha-blended 16x16 frame, 24 = the matte frame

        /// <summary>The small (16x16) icon chosen for the taskbar; Zero until Apply has run.</summary>
        public static IntPtr Small { get { return _small; } }

        // HICON from the .ico frame with the given size and bit depth, picked here instead of by Windows or .NET:
        // on a 24-bit display XP ignores the 32-bit alpha frame and would otherwise fall back to the rough 8-bit one.
        static IntPtr Frame(byte[] ico, int size, int bits)
        {
            int n = ico[4] | (ico[5] << 8), best = -1;
            for (int i = 0; i < n; i++)
            {
                int e = 6 + 16 * i;
                int w = ico[e] == 0 ? 256 : ico[e], bpp = ico[e + 6] | (ico[e + 7] << 8);
                if (w == size && bpp == bits) { best = e; break; }
            }
            if (best < 0) return IntPtr.Zero;
            int len = BitConverter.ToInt32(ico, best + 8), off = BitConverter.ToInt32(ico, best + 12);
            byte[] img = new byte[len];
            Array.Copy(ico, off, img, 0, len);
            return CreateIconFromResourceEx(img, len, true, 0x00030000, size, size, 0);
        }

        public static void Apply(Form f)
        {
            try
            {
                if (!_loaded)
                {
                    _loaded = true;
                    IntPtr[] l = new IntPtr[1], s = new IntPtr[1];
                    if (ExtractIconEx(Application.ExecutablePath, 0, l, s, 1) > 0) { _large = l[0]; _small = s[0]; }
                    try
                    {
                        using (System.IO.Stream st = System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("spotipaq.ico"))
                            if (st != null)
                            {
                                byte[] ico = new byte[st.Length];
                                int got = 0;
                                while (got < ico.Length) { int r = st.Read(ico, got, ico.Length - got); if (r <= 0) break; got += r; }
                                IntPtr h = Frame(ico, 16, SmallBits);
                                if (h == IntPtr.Zero) h = Frame(ico, 16, 24);
                                if (h != IntPtr.Zero) _small = h;
                            }
                    }
                    catch { }
                }
                if (f.IsHandleCreated)
                {
                    if (_small != IntPtr.Zero) SendMessage(f.Handle, 0x80, IntPtr.Zero, _small);   // WM_SETICON, ICON_SMALL
                    if (_large != IntPtr.Zero) SendMessage(f.Handle, 0x80, new IntPtr(1), _large); // ICON_BIG
                }
            }
            catch { }
        }
    }
}